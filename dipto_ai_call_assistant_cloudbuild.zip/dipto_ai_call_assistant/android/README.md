# DIPTO AI Android project (prototype)

This Android Studio project packages the current HTML prototype in a WebView.

## Build APK
1. Open the `android` folder in Android Studio.
2. Wait for Gradle sync.
3. Select **Build > Build APK(s)**.
4. The debug APK will appear under `app/build/outputs/apk/debug/`.

## Current limitations
- Excluded-number list is local to this app (browser/WebView local storage).
- Call history and demo-call summaries are simulated.
- This project does not access, screen, intercept, answer, or route SIM calls.
- Live calling needs a supported telephony provider and call-routing setup, and must be configured transparently so callers know they are speaking to an AI.
