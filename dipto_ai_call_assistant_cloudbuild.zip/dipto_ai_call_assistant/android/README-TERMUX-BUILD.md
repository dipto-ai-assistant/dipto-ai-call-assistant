# DIPTO AI APK build (phone-friendly cloud build)

This project includes a GitHub Actions workflow to build a debug APK without installing Android SDK/Gradle on your phone.

## Steps
1. Create a GitHub repository and upload the contents of this project folder. Keep `android/` as the repository root (the `.github/workflows/build-apk.yml` file must be in the root `.github/workflows/` folder).
2. On GitHub, open the repository's **Actions** tab and select **Build DIPTO AI APK**.
3. Tap **Run workflow** and run it on the `main` branch. If you push to `main`, it also runs automatically.
4. When the run succeeds, open the run page, scroll to **Artifacts**, and download `dipto-ai-debug-apk`.
5. Extract the artifact ZIP to get `app-debug.apk`; install it on your Android phone.

The current APK is a local UI/demo only. It does not answer real SIM calls or connect to a voice AI backend.
